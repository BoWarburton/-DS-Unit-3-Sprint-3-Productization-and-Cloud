""" Sprint Challenge OpenAQ Air Quality Dashboard with Flask
The main route return a dashboard page with three buttons:
Cities is the stretch goal for part 2, add another interesting request
Refresh pulls fresh data and replaces the existing data
10+ shows datetime and readings where PM 2.5 is >= 10"""

"""OpenAQ Air Quality Dashboard with Flask."""
from flask import Flask, render_template, request
from flask_sqlalchemy import SQLAlchemy
import openaq

APP = Flask(__name__)
api = openaq.OpenAQ()

APP.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///db.sqlite3'
APP.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
DB = SQLAlchemy(APP)


@APP.route('/')
def root():
    return """<!DOCTYPE html>
<html>
  <head>
    <title>Air Quality - {{ title }}</title>
    <link rel="stylesheet" href="https://unpkg.com/picnic"/>
  </head>
  <body>
    <nav>
        <a href="/" class="brand"><span>AQ App</span></a>

      <!-- responsive-->
      <input id="bmenub" type="checkbox" class="show">
      <label for="bmenub" class="burger pseudo button">Menu</label>

      <div class="menu">
        <a href="/cities" class="button warning">Cities</a>
        <a href="/refresh" class="button warning">Refresh</a>
        <a href="/risky" class="button warning">10+</a>
      </div>
    </nav>
    <article class="flex two" style="padding: 3em 1em;">
      <div>
      <h2>Sprint Challenge OpenAQ Air Quality Dashboard with Flask</h2>
      <h4>The main route return a dashboard page with three buttons:</h4>
      <ul>
      <li>Cities is the stretch goal for part 2</li>
      <li>Refresh pulls fresh data and replaces the existing data</li>
      <li>10+ shows datetime and readings where PM 2.5 is >= 10</li>
      </ul>
      </div>
    </article>
  </body>
</html>
"""


@APP.route('/risky')
def risky():
    """Datetime, reading where value >= 10"""
    return 'Potentially risky PM2.5 readings<br />' \
           '{}'.format(Record.query.filter(Record.value >= 10).all())


def get_api_data(city='Los Angeles', parameter='pm25'):
    status, body = api.measurements(city=city, parameter=parameter)
    my_list = []
    for date, result in zip(body['results'], body['results']):
        my_list.append(((date['date']['utc']), (result['value'])))
    return my_list


class Record(DB.Model):
    id = DB.Column(DB.Integer, primary_key=True)
    datetime = DB.Column(DB.String(25))
    value = DB.Column(DB.Float, nullable=False)

    def __repr__(self):
        return '-Time {} Reading {}-<br />'.format(self.datetime, self.value)


@APP.route('/refresh')
def refresh():
    """Pull fresh data from Open AQ and replace existing data."""
    DB.drop_all()
    DB.create_all()
    new_data = get_api_data()
    for result in new_data:
        db_record = Record(datetime=result[0], value=result[1])
        DB.session.add(db_record)
    DB.session.commit()
    return 'Data refreshed!'


@APP.route('/cities')
def get_api_cities(country="NL", limit=50):
    """ Returns list of dictionaries with city, country, count, number of locations """
    status, body = api.cities(country=country, limit=limit)
    cities_list = []
    for city in body['results']:
        cities_list.append(city['name'])
    return str(cities_list)
